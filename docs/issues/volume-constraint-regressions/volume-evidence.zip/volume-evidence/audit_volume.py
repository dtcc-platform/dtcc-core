"""Audit captured or replayed cells; exact signs use the stored float coordinates.

This diagnostic does not replace the full ownership/roof-coverage acceptance suite.
Run: python audit_volume.py lund
Replay the supplied PLC: python audit_volume.py lund --replay --output replay.npz
Exit status is 1 for a reproduced geometric defect, 0 if these checks pass.
"""
from pathlib import Path
from fractions import Fraction as F
import argparse, itertools, json, math
import numpy as np
import shapely
from shapely.geometry import shape

ROOT = Path(__file__).resolve().parent

def in_ring(q, coordinates):
    inside = False
    x, y = q
    for a, b in zip(coordinates, coordinates[1:]):
        ax, ay, bx, by = map(lambda z: F(float(z)), [*a[:2], *b[:2]])
        cross = (bx - ax) * (y - ay) - (by - ay) * (x - ax)
        if cross == 0 and min(ax, bx) <= x <= max(ax, bx) and min(ay, by) <= y <= max(ay, by):
            return 0
        if (ay > y) != (by > y) and ((cross > 0) == (by > ay)):
            inside = not inside
    return 1 if inside else -1

def exact_inside(q, polygon):
    return in_ring(q, list(polygon.exterior.coords)) == 1 and all(
        in_ring(q, list(h.coords)) == -1 for h in polygon.interiors)

def determinant_volume(points):
    p = [[F(float(x)) for x in row] for row in points]
    a, b, c = [[row[k] - p[0][k] for k in range(3)] for row in p[1:]]
    return (a[0]*(b[1]*c[2]-b[2]*c[1]) - a[1]*(b[0]*c[2]-b[2]*c[0])
            + a[2]*(b[0]*c[1]-b[1]*c[0])) / 6

def audit(vertices, cells, features):
    p = vertices[cells]
    volumes = np.einsum('ij,ij->i', p[:,1]-p[:,0], np.cross(p[:,2]-p[:,0], p[:,3]-p[:,0])) / 6
    twice_areas = np.max([np.linalg.norm(np.cross(p[:,j]-p[:,i], p[:,k]-p[:,i]), axis=1)
                         for i,j,k in itertools.combinations(range(4),3)], axis=0)
    altitude = 6 * volumes / twice_areas
    edges2 = sum(np.sum((p[:,i]-p[:,j])**2, axis=1) for i,j in itertools.combinations(range(4),2))
    quality = 72 * math.sqrt(3) * np.abs(volumes) / np.sqrt(edges2**3)
    polygons = [shape(f['geometry']) for f in features]
    roofs = [f['properties']['z'] for f in features]
    centers = p.mean(axis=1)
    # Search padding ONLY selects candidates. Exact point-in-polygon has no XY tolerance.
    pad = 1e-7
    ii, jj = shapely.STRtree(polygons).query(shapely.box(centers[:,0]-pad, centers[:,1]-pad,
                                                     centers[:,0]+pad, centers[:,1]+pad))
    crossings = []
    for i,j in zip(ii,jj):
        if centers[i,2] >= roofs[j] - 1e-6:
            continue
        q = [sum(F(float(x)) for x in p[i,:,k]) / 4 for k in range(3)]
        if q[2] < F(float(roofs[j])) - F(1e-6) and exact_inside(q[:2], polygons[j]):
            crossings.append({'cell': int(i), 'roof_index': int(j), 'roof_z': roofs[j],
                              'centroid': [float(x) for x in q]})
    tiny = np.flatnonzero((volumes < 1e-9) | (altitude < 1e-9))
    return {'cells': len(cells), 'finite_positive': bool(np.isfinite(volumes).all() and (volumes > 0).all()),
            'minimum_volume_m3': float(volumes.min()), 'minimum_altitude_m': float(altitude.min()),
            'minimum_quality': float(quality.min()), 'quality_below_0_02': int((quality < .02).sum()),
            'tiny_cell_count': len(tiny), 'exact_below_roof_count': len(crossings), 'crossings': crossings,
            'tiny_cells': [{'cell': int(i), 'exact_volume_m3': str(determinant_volume(p[i]))}
                           for i in tiny],
            'diagnostic_limits': '1e-9 m3 and 1e-9 m altitude are diagnostic bins, not universal quality standards.'}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('case', choices=['lund','synthetic-6','synthetic-8'])
    parser.add_argument('--replay', action='store_true')
    parser.add_argument('--mesh', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    if args.replay:
        if args.output is None:
            parser.error('--replay requires --output to a new NPZ file')
        if args.output.exists():
            parser.error('Output exists; select a new path')
        import dtcc_tetgen_wrapper as tetwrap
        plc = np.load(ROOT / f'{args.case}-plc.npz', allow_pickle=False)
        options = json.loads((ROOT / 'tetgen-options.json').read_text())
        mesh = tetwrap.tetrahedralize(vertices=plc['vertices'], faces=plc['faces'],
            face_markers=plc['face_markers'], boundary_facets=plc['boundary_facets'],
            boundary_facet_markers=plc['boundary_facet_markers'], return_io=True, **options)
        vertices, cells = np.asarray(mesh.points), np.asarray(mesh.tets)
        np.savez_compressed(args.output, vertices=vertices, cells=cells)
        expected = np.load(ROOT / f'{args.case}-volume.npz', allow_pickle=False)
        print(json.dumps({'replay_vertices_identical': np.array_equal(vertices, expected['vertices']),
                          'replay_cells_identical': np.array_equal(cells, expected['cells'])}))
    else:
        data = np.load(args.mesh or ROOT / f'{args.case}-volume.npz', allow_pickle=False)
        vertices, cells = data['vertices'], data['cells']
    features = json.loads((ROOT / f'{args.case}-roofs.geojson').read_text())['features']
    result = audit(vertices, cells, features)
    print(json.dumps(result, indent=2))
    return int(not result['finite_positive'] or result['tiny_cell_count'] > 0 or result['exact_below_roof_count'] > 0)

if __name__ == '__main__':
    raise SystemExit(main())
