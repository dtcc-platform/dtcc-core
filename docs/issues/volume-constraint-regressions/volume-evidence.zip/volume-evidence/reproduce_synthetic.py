"""Reproduce either small public case through the core pipeline and capture its PLC.

Use the documented core checkpoint for exact baseline reproduction. Output must
be a new directory. No provider data, test imports or scratch paths are needed.
"""
from pathlib import Path
import argparse, json
import numpy as np
import shapely
from shapely.geometry import shape
from dtcc_core.model import Bounds, Building, City, GeometryType, Raster, Surface, Terrain
from dtcc_core.builder.geometry_builders import meshes
from audit_volume import audit

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('case', choices=['synthetic-6','synthetic-8'])
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
args.output.mkdir(parents=True, exist_ok=False)
features = json.loads((ROOT / f'{args.case}-sources.geojson').read_text())['features']
city = City(id='city')
polygons = []
for i, f in enumerate(features):
    polygon = shape(f['geometry']); polygons.append(polygon)
    z = f['properties']['roof']
    surface = Surface(); surface.from_polygon(polygon,z)
    building = Building(id=str(i)); building.add_geometry(surface,GeometryType.LOD0)
    building.estimated_height = float(z); building.attributes['ground_height'] = 0
    city.add_buildings([building])
raster = Raster(); raster.data = np.zeros((4,4))
xmin,ymin,xmax,ymax = shapely.union_all(polygons).bounds
raster.set_bounds(Bounds(xmin-10,ymin-10,xmax+10,ymax+10))
terrain = Terrain(); terrain.add_geometry(raster,GeometryType.RASTER); city.add_terrain(terrain)
city = city.clean_footprints()
original = meshes.tetgen_build_volume_mesh
def capture(**kwargs):
    p = kwargs['prebuilt_plc']
    np.savez_compressed(args.output / f'{args.case}-plc.npz', vertices=p.vertices,
        faces=p.shell_faces, face_markers=kwargs['mesh'].markers,
        boundary_facets=np.asarray(p.boundary_facets,dtype=np.int64),
        boundary_facet_markers=np.asarray(p.boundary_facet_markers,dtype=np.int64))
    options = {k:kwargs[k] for k in ['switches_params','switches_overrides','return_boundary_faces']}
    (args.output/'tetgen-options.json').write_text(json.dumps(options,indent=2))
    return original(**kwargs)
meshes.tetgen_build_volume_mesh = capture
mesh = meshes.build_city_volume_mesh(city,lod=GeometryType.LOD0,min_building_detail=.5,
    min_building_area=0,max_mesh_size=5,domain_height=60,report_mesh_quality=False)
np.savez_compressed(args.output/f'{args.case}-volume.npz',vertices=mesh.vertices,cells=mesh.cells)
expected = np.load(ROOT/f'{args.case}-volume.npz',allow_pickle=False)
result = audit(mesh.vertices,mesh.cells,json.loads((ROOT/f'{args.case}-roofs.geojson').read_text())['features'])
result['vertices_identical'] = np.array_equal(mesh.vertices,expected['vertices'])
result['cells_identical'] = np.array_equal(mesh.cells,expected['cells'])
(args.output/'audit.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
raise SystemExit(int(result['tiny_cell_count']>0 or result['exact_below_roof_count']>0))
