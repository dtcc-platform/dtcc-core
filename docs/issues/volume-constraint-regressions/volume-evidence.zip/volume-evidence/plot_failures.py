"""Render scientific illustrations from captured mesh coordinates."""
from pathlib import Path
from fractions import Fraction as F
import itertools, json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.path import Path as PlotPath
from matplotlib.patches import PathPatch
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable
from shapely.geometry import shape
from shapely.geometry.polygon import orient

ROOT = Path(__file__).resolve().parent
plt.rcParams.update({'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False})
BLUE, RED = '#3578a8', '#c83e3e'
data = np.load(ROOT / 'lund-volume.npz')
v, c = data['vertices'], data['cells']
tet = v[c]
volumes = np.einsum('ij,ij->i', tet[:,1]-tet[:,0], np.cross(tet[:,2]-tet[:,0], tet[:,3]-tet[:,0]))/6
tiny = np.flatnonzero(volumes < 1e-9)
features = json.loads((ROOT / 'lund-roofs.geojson').read_text())['features']
origin = np.array([386500., 6174500.])
polygons, heights = [], []
for f in features:
    polygon = orient(shape(f['geometry']), sign=1)
    paths = []
    for ring in [polygon.exterior, *polygon.interiors]:
        xy = np.asarray(ring.coords)[:,:2] - origin
        paths.append(PlotPath(xy, [PlotPath.MOVETO]+[PlotPath.LINETO]*(len(xy)-2)+[PlotPath.CLOSEPOLY]))
    polygons.append(PlotPath.make_compound_path(*paths))
    heights.append(f['properties']['z'])
centers = tet[tiny].mean(axis=1)[:,:2] - origin
fig, axes = plt.subplots(1,2,figsize=(12,5.6),layout='constrained')
for ax in axes:
    collection = ScalarMappable(norm=Normalize(min(heights),max(heights)),cmap='viridis')
    for polygon,height in zip(polygons,heights):
        ax.add_patch(PathPatch(polygon,facecolor=collection.to_rgba(height),
                              edgecolor='#e6edf3',linewidth=.5,alpha=.82))
    ax.scatter(centers[:,0], centers[:,1], marker='x', s=70, color=RED, linewidth=1.6,
               label='20 near-flat tetrahedra (XY centroids)', zorder=4)
    ax.set_aspect('equal'); ax.set_xlabel('Easting − 386500 [m]'); ax.set_ylabel('Northing − 6174500 [m]')
axes[0].autoscale(); axes[0].set_title('Lund 056 · captured roof partition and volume failures')
axes[0].legend(loc='upper left',fontsize=8)
axes[1].set_xlim(5,23); axes[1].set_ylim(37,62); axes[1].set_title('Detail · failures cluster along wall constraints')
axes[1].annotate('Cell 39672', xy=centers[list(tiny).index(39672)], xytext=(17,40),
                 arrowprops={'arrowstyle':'->','color':RED},color=RED)
fig.colorbar(collection,ax=axes,shrink=.75,label='Roof elevation [m]')
fig.suptitle('Good surface triangles do not exclude nearly flat volume cells',fontsize=15)
fig.savefig(ROOT / 'lund-overview.png',dpi=170);plt.close(fig)

counter = json.loads((ROOT / 'counterexample.json').read_text())
p = np.asarray(counter['raw_float_counterexample']['vertices'])
ring = np.asarray(counter['intended_roof_region']['geometry']['coordinates'][0])
a,b = ring[8,:2],ring[9,:2]
direction = b-a; length = np.linalg.norm(direction); unit = direction/length
along = (p[:,:2]-a)@unit
af,bf = [F(float(x)) for x in a],[F(float(x)) for x in b]
normal = np.array([float((bf[0]-af[0])*(F(float(q[1]))-af[1]) -
                        (bf[1]-af[1])*(F(float(q[0]))-af[0]))/length for q in p])*1e9
fig,axes = plt.subplots(1,2,figsize=(11.4,5.4),layout='constrained')
for i,j in itertools.combinations(range(4),2):
    axes[0].plot(along[[i,j]]*100,p[[i,j],2],color=BLUE,lw=1.8)
    axes[1].plot(normal[[i,j]],p[[i,j],2],color=BLUE,lw=1.8)
for ax,x in zip(axes,[along*100,normal]):
    ax.scatter(x,p[:,2],color=BLUE,s=35,zorder=4)
    for k in range(4):ax.annotate(str(k),(x[k],p[k,2]),xytext=(5,5),textcoords='offset points')
    ax.scatter(x.mean(),p[:,2].mean(),color=RED,s=45,label='Tetrahedron centroid',zorder=5)
    ax.set_ylabel('Elevation [m]');ax.grid(alpha=.15)
axes[0].set_xlabel('Distance along original wall segment [cm]')
axes[0].set_title('Along-wall projection · edges up to 49 cm')
axes[1].axvline(0,color='black',ls='--',lw=1,label='Intended wall plane')
axes[1].set_xlabel('Signed distance normal to wall [nanometres]')
axes[1].set_title('Normal projection · lateral scale magnified')
axes[1].set_xlim(min(-.1,normal.min()-.08),max(.1,normal.max()+.08));axes[1].legend(loc='upper right',fontsize=8)
fig.suptitle('Lund cell 39672 · volume 4.34 × 10⁻¹⁴ m³ · minimum altitude 0.0113 nm',fontsize=13)
fig.supxlabel('Projection of actual stored vertices. Axis units differ; this is not an isotropic view.\nCentroid is below the 44.862 m roof and strictly inside its XY region.',fontsize=10)
fig.savefig(ROOT / 'lund-cell.png',dpi=170);plt.close(fig)

rows = json.loads((ROOT / 'transform-matrix.json').read_text())
cases = list(dict.fromkeys(r['case'] for r in rows)); counts=np.zeros((len(cases),2),int)
labels=[]
for i,case in enumerate(cases):
    a=case.split('-');labels.append(f'{a[0][1:]} spokes / {a[1][1:]}° / '+('origin' if '-t0.0-' in case else '100k,200k' if '-t100000' in case else 'Swedish grid'))
    for j,rev in enumerate(['baseline','candidate']):counts[i,j]=next(r['volumes_below_1e_9'] for r in rows if r['case']==case and r['revision']==rev)
fig,ax=plt.subplots(figsize=(7.5,8.7),layout='constrained')
ax.imshow(counts,cmap='Reds',vmin=0,vmax=2,aspect='auto')
ax.set_xticks([0,1],['Frozen implementation','Rejected guarded prototype'])
ax.set_yticks(range(len(labels)),labels)
for i,j in itertools.product(range(len(cases)),range(2)):ax.text(j,i,str(counts[i,j]),ha='center',va='center',color='white' if counts[i,j]>1 else '#222')
ax.set_title('Near-flat cells across 18 rotation / translation cases\nCount with volume < 10⁻⁹ m³ (diagnostic threshold)',pad=18)
fig.supxlabel('Baseline: 2 failing cases. Prototype: 3 failing cases.\nAll 36 meshes had zero PLC shell triangles below quality 0.02.',fontsize=10)
fig.savefig(ROOT/'transformed-cases.png',dpi=150);plt.close(fig)
